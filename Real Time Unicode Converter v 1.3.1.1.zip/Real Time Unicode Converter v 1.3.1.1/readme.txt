Real-Time Unicode Converter V1.3.1.1

If you can't see any words and "?" Only if displayed in the app. Please use unicode typing tool like Helakuru, Google input tool

If you want to paste any text into this app. Please change your computer's font input type (from SI to EN).

Fonts and info.pdf are included in setup file.("Click on "About" button).

That info.pdf file also included with setup file (open "Sources" folder) 

Please email me if you find any bugs in this app.



~~~~~~~~~~~~Thank you~~~~~~~~~~~~
~~~~~~~~~~~~~~NITH~~~~~~~~~~~~~~